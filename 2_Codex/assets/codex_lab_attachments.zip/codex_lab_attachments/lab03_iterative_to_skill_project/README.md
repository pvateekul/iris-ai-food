Lab 3 intentionally has no references/ or templates/ folder. Paste rubric, risk rules, and template in later prompt turns.
