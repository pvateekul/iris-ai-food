# Corrective Action Examples

## Cooling Delay

Possible containment:
- Hold affected batch for QA review.
- Verify product temperature records.
- Confirm whether release criteria were met.

Possible corrective actions:
- Review cooling load size and tray spacing.
- Check chiller performance and maintenance records.
- Confirm probe placement and recording method.

Possible preventive actions:
- Add cooling start/end timestamp checks.
- Add escalation rule when cooling exceeds target time.
- Review shift handover for cooling batches.

## Label Mix-up

Possible containment:
- Quarantine affected finished goods.
- Perform label reconciliation.
- Check allergen and shelf-life information before release.

Possible corrective actions:
- Review line clearance procedure.
- Add second-person verification during label changeover.
- Check printer template access and version control.

Possible preventive actions:
- Add label changeover checklist.
- Train operators on high-risk label fields.
- Review recurring label deviation trend monthly.

## Metal Detection Reject

Possible containment:
- Hold affected product since last good check.
- Re-run detector challenge test.
- Inspect rejected units according to SOP.

Possible corrective actions:
- Check detector sensitivity and calibration records.
- Review product effect settings.
- Confirm reject mechanism function.

Possible preventive actions:
- Increase verification frequency for affected product.
- Add maintenance review if repeated rejects occur.
- Review foreign material prevention controls.
