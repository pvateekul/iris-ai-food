---
name: food-process-visualizer
description: Creates simple PNG charts from food deviation logs and plot requests, then saves them under assets/plots/.
---

# Food Process Visualizer

This skill creates simple, readable charts from food process deviation data.

The goal is to help QA and production teams quickly see repeated issue patterns, affected process areas, and priority risks.

## When to Use This Skill

Use this skill when the task involves:

- Creating charts from food deviation logs
- Visualizing repeated issue patterns
- Showing deviations by line, shift, product, process step, severity, or status
- Creating PNG figures for a QA review report
- Turning `assets/plot_requests.md` into chart files

## Typical Inputs

This skill may use:

- `data/food_deviation_log.csv`
- `assets/deviation_pattern_summary.md`
- `assets/plot_requests.md`
- `references/brand_voice.md`

Expected useful columns may include:

- `date`
- `product`
- `line`
- `shift`
- `process_step`
- `deviation_type`
- `severity`
- `status`
- `owner`
- `action_taken`

If required columns are missing, do not invent data. State the gap in the plot manifest.

## Plot Request Format

If `assets/plot_requests.md` exists, read it and create the requested charts.

Expected format:

```md
# Plot Requests

## Plot 1

Title: Deviations by Process Step
Data source: data/food_deviation_log.csv
Chart type: bar chart
X-axis: process_step
Y-axis: count of deviations
Output file: assets/plots/deviations_by_process_step.png
Purpose: Show which process steps have the most recorded deviations.

## Plot 2

Title: Deviations by Production Line
Data source: data/food_deviation_log.csv
Chart type: bar chart
X-axis: line
Y-axis: count of deviations
Output file: assets/plots/deviations_by_line.png
Purpose: Show which production lines have repeated issues.
```

If no plot request file exists, create 2–3 useful default charts from the available data.

## Recommended Default Charts

Create only charts supported by available columns.

Useful defaults:

1. Deviations by process step
2. Deviations by production line
3. Deviations by severity
4. Deviations by deviation type
5. Open actions by status or owner
6. Repeated issues by product
7. Deviation trend over time, if date data is available

## Workflow

1. Read the deviation log.
2. Inspect available columns.
3. Read plot requests if available.
4. Validate that each requested plot can be created from available columns.
5. Create the `assets/plots/` folder if it does not exist.
6. Generate simple PNG charts.
7. Use clear titles, axis labels, and readable text.
8. Save each plot as a PNG file.
9. Create `assets/plot_manifest.md` summarizing:
   - chart title
   - output file path
   - data used
   - what the chart shows
   - any missing fields or limitations

## Output Requirements

Save plots under:

```text
assets/plots/
```

Create a manifest:

```md
# Plot Manifest

## Created Plots

| Plot | File | Data Used | What It Shows | Notes |
|---|---|---|---|---|

## Skipped or Unsupported Plots

| Requested Plot | Reason Skipped |
|---|---|
```

## Chart Style Guidelines

- Keep charts simple and readable.
- Prefer bar charts for categorical summaries.
- Prefer line charts only when date/time data is meaningful.
- Use clear chart titles.
- Use clear axis labels.
- Rotate x-axis labels if needed.
- Avoid clutter.
- Do not create decorative charts that do not support the QA review.

## Technical Guidance

If writing Python code:

- Use `pandas` for loading and grouping data.
- Use `matplotlib` for plotting.
- Save figures using `plt.savefig(...)`.
- Use `plt.tight_layout()` before saving.
- Close figures after saving with `plt.close()`.
- Do not use seaborn unless the project explicitly allows it.
- Do not require internet access.
- Do not modify raw data.

## Guardrails

- Do not invent values.
- Do not create misleading charts.
- Do not plot fields that are not present.
- Do not overstate findings from small counts.
- If data is incomplete, explain the limitation in `plot_manifest.md`.
