---
name: quality-report-writer
description: Writes concise food process quality review reports by combining deviation patterns, RCA hypotheses, follow-up questions, and corrective action plans.
---

# Quality Report Writer

This skill creates a concise final quality review report for QA and production stakeholders.

It combines the outputs from deviation analysis, RCA hypothesis building, follow-up questions, and corrective action planning.

## When to Use This Skill

Use this skill when the task involves:

- Writing a final QA review report
- Summarizing food process deviation analysis
- Creating a manager-friendly quality report
- Combining multiple analysis outputs into one document
- Preparing a workshop-friendly final artifact

## Typical Inputs

This skill may use:

- `assets/deviation_pattern_summary.md`
- `assets/rca_hypothesis_table.md`
- `assets/follow_up_questions.md`
- `assets/corrective_action_plan.md`
- `references/report_template.md`
- `references/brand_voice.md`

## Workflow

1. Read all available analysis outputs.
2. Extract the most important findings.
3. Remove duplicate points.
4. Keep evidence and assumptions separate.
5. Summarize issue patterns.
6. Summarize likely contributing factors.
7. Summarize missing information.
8. Summarize recommended actions.
9. End with clear next steps.

## Output Requirements

```md
# Food Process Quality Review Report

## Executive Summary

Short summary of the main issue patterns and recommended focus.

## Data Reviewed

- Source files:
- Date range:
- Number of records:
- Key limitations:

## Main Findings

| Finding | Evidence | Risk / Impact | Priority |
|---|---|---|---|

## RCA Support Summary

| Issue Pattern | Possible Contributing Factor | Confidence | Missing Information |
|---|---|---|---|

## Recommended Follow-up

1.
2.
3.

## Corrective / Preventive Action Summary

| Action | Owner | Priority | Evidence Needed |
|---|---|---|---|

## Open Questions

-

## Final Notes

This report supports QA review and investigation. It should not be treated as final root cause confirmation unless evidence is explicit.
```

## Style Guidelines

- Clear
- Concise
- Practical
- Operational
- Evidence-based
- Not alarmist
- Not overly technical

## Guardrails

- Do not overclaim.
- Do not invent missing records.
- Do not hide uncertainty.
- Do not write a long academic report.
- Keep the report useful for QA and production teams.
