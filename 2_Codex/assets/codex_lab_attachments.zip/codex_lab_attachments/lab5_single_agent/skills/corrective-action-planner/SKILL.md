---
name: corrective-action-planner
description: Creates practical corrective and preventive action plans for food process deviations based on observed patterns and RCA hypotheses.
---

# Corrective Action Planner

This skill helps convert food process issue patterns and RCA hypotheses into practical follow-up actions.

It should separate immediate containment, corrective action, and preventive action.

## When to Use This Skill

Use this skill when the task involves:

- Suggesting corrective actions
- Suggesting preventive actions
- Creating QA or production action plans
- Assigning action owners
- Defining evidence needed to close an issue
- Turning RCA findings into operational next steps

## Action Types

Use these categories:

1. **Containment**
   - Immediate action to reduce risk now

2. **Corrective Action**
   - Action to address the confirmed or likely cause

3. **Preventive Action**
   - Action to reduce recurrence

4. **Verification**
   - Evidence needed to confirm the action worked

## Typical Inputs

This skill may use:

- `assets/deviation_pattern_summary.md`
- `assets/rca_hypothesis_table.md`
- `assets/follow_up_questions.md`
- `references/qa_guidelines.md`
- `references/corrective_action_examples.md`

## Workflow

1. Read the issue pattern and RCA hypotheses.
2. Identify whether evidence is strong, partial, or missing.
3. Recommend containment actions first if risk is high.
4. Suggest corrective actions linked to likely contributing factors.
5. Suggest preventive actions linked to repeated patterns.
6. Assign likely owners.
7. Define closure evidence.
8. Note any actions that require confirmation before implementation.

## Output Requirements

```md
# Corrective Action Plan

## Summary

Briefly describe the issue pattern and action focus.

## Action Plan

| Action Type | Recommended Action | Owner | Priority | Evidence Needed | Notes |
|---|---|---|---|---|---|

## Immediate Containment
-

## Corrective Actions
-

## Preventive Actions
-

## Verification Plan
-

## Open Risks
-
```

## Guardrails

- Do not recommend extreme actions unless justified.
- Do not claim actions will eliminate risk completely.
- Do not assign blame.
- Tie each action to observed evidence or stated assumptions.
- If evidence is incomplete, recommend investigation before final CAPA.
