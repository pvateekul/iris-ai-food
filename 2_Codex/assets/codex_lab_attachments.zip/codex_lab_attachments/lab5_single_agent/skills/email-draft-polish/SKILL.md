---
name: email-draft-polish
description: Drafts or polishes concise follow-up emails for QA, production, supplier, or management audiences.
---

# Email Draft & Polish

This skill creates clear, concise emails for food process quality follow-up.

## When to Use This Skill

Use this skill when the task involves:

- Drafting a QA follow-up email
- Writing to production managers
- Writing to suppliers
- Requesting missing information
- Sharing corrective action next steps
- Summarizing a quality review

## Typical Inputs

This skill may use:

- `assets/final_quality_review.md`
- `assets/follow_up_questions.md`
- `assets/corrective_action_plan.md`
- `references/brand_voice.md`

## Inputs to Consider

Before drafting, identify:

- Recipient or audience
- Purpose of the email
- Required action
- Deadline, if provided
- Key evidence or issue pattern
- Tone
- Attachments or linked reports, if any

If recipient, deadline, or required action is missing, use a placeholder or state the gap.

## Workflow

1. Identify the email goal.
2. Identify the audience.
3. Extract the most important message.
4. Put the request or CTA clearly.
5. Keep paragraphs short.
6. Use calm, operational language.
7. Avoid blame.
8. Include next steps.

## Output Requirements

```md
# QA Follow-up Email

Subject: [Clear subject line]

Hi [Name / Team],

[Short context paragraph.]

[Main issue or finding.]

[Requested action or questions.]

[Deadline or next step, if available.]

Best,  
[Sender]
```

## Optional Format

For multiple questions, use bullets:

```md
Could you please help confirm:

- Question 1
- Question 2
- Question 3
```

## Style Guidelines

- Clear
- Polite
- Concise
- Operational
- Not alarmist
- Not blame-oriented

## Guardrails

- Do not invent names, deadlines, or commitments.
- Do not overstate the severity.
- Do not claim root cause is confirmed unless explicitly supported.
- Keep the email easy to send after light review.
