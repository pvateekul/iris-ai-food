# skin_cancer_segmentation > 2025-12-26 3:29pm
https://universe.roboflow.com/test-boi5h/skin_cancer_segmentation

Provided by a Roboflow user
License: CC BY 4.0

